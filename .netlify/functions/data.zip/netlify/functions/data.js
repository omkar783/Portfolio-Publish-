var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var data_exports = {};
__export(data_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(data_exports);
var import_blobs = require("@netlify/blobs");
const headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
};
const SITE_ID = "fbe98425-ef20-42ae-9d7b-d0fc74cc2ef6";
const handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  try {
    const token = process.env.NETLIFY_ACCESS_TOKEN || process.env.NETLIFY_AUTH_TOKEN;
    if (!token) {
      return { statusCode: 500, headers, body: "No token available" };
    }
    const store = (0, import_blobs.getStore)({
      name: "portfolio-live",
      siteID: SITE_ID,
      token
    });
    if (event.httpMethod === "GET") {
      const data = await store.get("content", { type: "json" });
      return {
        statusCode: 200,
        headers: { ...headers, "Content-Type": "application/json" },
        body: JSON.stringify(data || null)
      };
    }
    if (event.httpMethod === "POST") {
      const body = JSON.parse(event.body);
      if (body.password !== process.env.ADMIN_PASSWORD) {
        return { statusCode: 401, headers, body: "Wrong password" };
      }
      await store.setJSON("content", body.data);
      return { statusCode: 200, headers, body: "Saved" };
    }
    return { statusCode: 404, headers, body: "Not found" };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { ...headers, "Content-Type": "application/json" },
      body: JSON.stringify({ error: err.message, stack: err.stack })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
